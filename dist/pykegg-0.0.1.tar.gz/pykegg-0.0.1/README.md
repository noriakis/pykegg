# pykegg
Analyze and visualize KEGG information using network approach

Using `biopython`, `igraph` and [`plotnine`](https://github.com/has2k1/plotnine), parse the KGML into `igraph` and easily plot the relevant information contained in KEGG Pathway in Python environment.
